20221106: old file
--------------------------------------------
CDE Panel emulation and xfce/gtk themes. Please see Wiki or install.txt

Unpack, and run 'cdepanel'. (Maybe do chmod u+x cdepanel first.) 
Tested on Xubuntu 17.10. 

Latest version 1.3 : Now includes configurable XFCE window decorations. Title
height and border width can be set in pixels, and the images necessary for xfwm
making up the border and window buttons will be generated from that. Also the 
panel app and gtk/xfce theme are now combined into a single package

To generate theme files without using the panel app, use the 'switchtheme' script.

edit AppImage...yml file
dan run appimage-builder
